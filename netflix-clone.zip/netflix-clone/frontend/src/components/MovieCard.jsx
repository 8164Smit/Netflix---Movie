import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const MovieCard = ({ movie, onDelete, onClick }) => {
  const navigate = useNavigate();
  const [imgError, setImgError] = useState(false);

  const handleDelete = (e) => {
    e.stopPropagation();
    onDelete(movie._id, movie.title);
  };

  const handleEdit = (e) => {
    e.stopPropagation();
    navigate(`/edit/${movie._id}`);
  };

  const getRatingColor = (r) => {
    if (r >= 8) return '#46d369';
    if (r >= 6) return '#f5c518';
    return '#e50914';
  };

  return (
    <div className="movie-card" onClick={() => onClick(movie)}>
      <div className="movie-card-img-wrap">
        {imgError ? (
          <div className="movie-card-img-fallback">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth="1.5">
              <rect x="2" y="2" width="20" height="20" rx="2" />
              <path d="M7 8l10 8M17 8L7 16" />
            </svg>
          </div>
        ) : (
          <img
            src={movie.imageUrl}
            alt={movie.title}
            className="movie-card-img"
            onError={() => setImgError(true)}
            loading="lazy"
          />
        )}
        <div className="movie-card-overlay">
          <div className="movie-card-info">
            <h3 className="movie-card-title">{movie.title}</h3>
            <div className="movie-card-meta">
              <span className="movie-card-year">{movie.releaseYear}</span>
              <span className="movie-card-genre">{movie.genre}</span>
            </div>
            <div className="movie-card-rating" style={{ color: getRatingColor(movie.rating) }}>
              ★ {movie.rating.toFixed(1)}
            </div>
            <p className="movie-card-desc">{movie.description.substring(0, 80)}...</p>
            <div className="movie-card-actions">
              <button className="btn-play" onClick={(e) => { e.stopPropagation(); onClick(movie); }}>
                ▶ Play
              </button>
              <button className="btn-edit" onClick={handleEdit} title="Edit">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                </svg>
              </button>
              <button className="btn-delete" onClick={handleDelete} title="Delete">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="3 6 5 6 21 6" />
                  <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                  <path d="M10 11v6M14 11v6" />
                  <path d="M9 6V4h6v2" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
