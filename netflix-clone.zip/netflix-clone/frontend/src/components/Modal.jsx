import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Modal = ({ movie, onClose, onDelete }) => {
  const navigate = useNavigate();

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    const handleKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleKey);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKey);
    };
  }, [onClose]);

  if (!movie) return null;

  const getRatingColor = (r) => {
    if (r >= 8) return '#46d369';
    if (r >= 6) return '#f5c518';
    return '#e50914';
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>
        <div className="modal-hero">
          <img
            src={movie.imageUrl}
            alt={movie.title}
            className="modal-poster"
            onError={(e) => { e.target.style.display = 'none'; }}
          />
          <div className="modal-hero-gradient" />
          <div className="modal-hero-content">
            <h2 className="modal-title">{movie.title}</h2>
            <div className="modal-badges">
              <span className="badge badge--year">{movie.releaseYear}</span>
              <span className="badge badge--genre">{movie.genre}</span>
              <span className="badge badge--rating" style={{ color: getRatingColor(movie.rating) }}>
                ★ {movie.rating.toFixed(1)}
              </span>
            </div>
          </div>
        </div>
        <div className="modal-body">
          <p className="modal-description">{movie.description}</p>
          <div className="modal-actions">
            <button
              className="btn-modal-edit"
              onClick={() => { navigate(`/edit/${movie._id}`); onClose(); }}
            >
              ✎ Edit Movie
            </button>
            <button
              className="btn-modal-delete"
              onClick={() => { onDelete(movie._id, movie.title); onClose(); }}
            >
              🗑 Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;
