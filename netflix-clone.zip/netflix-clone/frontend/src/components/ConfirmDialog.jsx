const ConfirmDialog = ({ title, onConfirm, onCancel }) => {
  return (
    <div className="modal-backdrop" onClick={onCancel}>
      <div className="confirm-box" onClick={(e) => e.stopPropagation()}>
        <div className="confirm-icon">🗑</div>
        <h3 className="confirm-title">Delete Movie?</h3>
        <p className="confirm-text">
          Are you sure you want to delete <strong>"{title}"</strong>?<br />
          This action cannot be undone.
        </p>
        <div className="confirm-actions">
          <button className="btn-cancel" onClick={onCancel}>Cancel</button>
          <button className="btn-confirm-delete" onClick={onConfirm}>Yes, Delete</button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmDialog;
