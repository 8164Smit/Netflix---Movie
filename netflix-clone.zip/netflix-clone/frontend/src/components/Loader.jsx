const Loader = ({ fullScreen = false }) => {
  return (
    <div className={fullScreen ? 'loader-fullscreen' : 'loader-inline'}>
      <div className="loader-ring">
        <div></div><div></div><div></div><div></div>
      </div>
    </div>
  );
};

export default Loader;
