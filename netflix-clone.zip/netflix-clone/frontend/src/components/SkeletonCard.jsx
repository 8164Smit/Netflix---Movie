const SkeletonCard = () => (
  <div className="skeleton-card">
    <div className="skeleton skeleton-img" />
  </div>
);

export const SkeletonRow = () => (
  <section className="movie-row">
    <div className="skeleton skeleton-title" />
    <div className="movie-row-track-wrap">
      <div className="movie-row-track">
        {[...Array(6)].map((_, i) => <SkeletonCard key={i} />)}
      </div>
    </div>
  </section>
);

export default SkeletonCard;
