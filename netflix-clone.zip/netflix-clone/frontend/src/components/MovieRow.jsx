import { useRef } from 'react';
import MovieCard from './MovieCard';

const MovieRow = ({ title, movies, onDelete, onCardClick }) => {
  const rowRef = useRef(null);

  const scroll = (dir) => {
    if (rowRef.current) {
      rowRef.current.scrollBy({ left: dir * 800, behavior: 'smooth' });
    }
  };

  if (!movies || movies.length === 0) return null;

  return (
    <section className="movie-row">
      <h2 className="movie-row-title">{title}</h2>
      <div className="movie-row-track-wrap">
        <button className="row-arrow row-arrow--left" onClick={() => scroll(-1)} aria-label="scroll left">
          ‹
        </button>
        <div className="movie-row-track" ref={rowRef}>
          {movies.map((movie) => (
            <MovieCard
              key={movie._id}
              movie={movie}
              onDelete={onDelete}
              onClick={onCardClick}
            />
          ))}
        </div>
        <button className="row-arrow row-arrow--right" onClick={() => scroll(1)} aria-label="scroll right">
          ›
        </button>
      </div>
    </section>
  );
};

export default MovieRow;
