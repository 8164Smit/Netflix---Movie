const BASE_URL = '/api/movies';

export const fetchMovies = async (search = '', genre = '') => {
  const params = new URLSearchParams();
  if (search) params.append('search', search);
  if (genre && genre !== 'All') params.append('genre', genre);
  const res = await fetch(`${BASE_URL}?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch movies');
  return res.json();
};

export const fetchMovieById = async (id) => {
  const res = await fetch(`${BASE_URL}/${id}`);
  if (!res.ok) throw new Error('Movie not found');
  return res.json();
};

export const createMovie = async (data) => {
  const res = await fetch(BASE_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to create movie');
  return json;
};

export const updateMovie = async (id, data) => {
  const res = await fetch(`${BASE_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to update movie');
  return json;
};

export const deleteMovie = async (id) => {
  const res = await fetch(`${BASE_URL}/${id}`, { method: 'DELETE' });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to delete movie');
  return json;
};

export const seedMovies = async () => {
  const res = await fetch(`${BASE_URL}/seed/data`, { method: 'POST' });
  if (!res.ok) throw new Error('Failed to seed data');
  return res.json();
};
