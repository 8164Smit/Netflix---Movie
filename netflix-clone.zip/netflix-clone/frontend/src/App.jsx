import { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import AddMovie from './pages/AddMovie';
import EditMovie from './pages/EditMovie';
import AllMovies from './pages/AllMovies';
import { ToastProvider } from './context/ToastContext';
import './styles.css';

const App = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [genreFilter, setGenreFilter] = useState('All');

  return (
    <BrowserRouter>
      <ToastProvider>
        <div className="app">
          <Navbar onSearch={setSearchQuery} />
          <main className="main-content">
            <Routes>
              <Route
                path="/"
                element={<Home searchQuery={searchQuery} genreFilter={genreFilter} />}
              />
              <Route path="/add" element={<AddMovie />} />
              <Route path="/edit/:id" element={<EditMovie />} />
              <Route
                path="/movies"
                element={<AllMovies searchQuery={searchQuery} />}
              />
            </Routes>
          </main>
          <footer className="footer">
            <p>© 2024 CineVault — Movie Management System</p>
          </footer>
        </div>
      </ToastProvider>
    </BrowserRouter>
  );
};

export default App;
