import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { fetchMovieById, updateMovie } from '../services/api';
import { useToast } from '../context/ToastContext';
import Loader from '../components/Loader';

const GENRES = ['Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi', 'Romance', 'Thriller', 'Animation', 'Documentary', 'Fantasy'];

const EditMovie = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToast } = useToast();

  const [form, setForm] = useState({
    title: '', description: '', genre: '', releaseYear: '', rating: '', imageUrl: '',
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetchMovieById(id);
        const m = res.data;
        setForm({
          title: m.title,
          description: m.description,
          genre: m.genre,
          releaseYear: m.releaseYear,
          rating: m.rating,
          imageUrl: m.imageUrl,
        });
        setPreview(m.imageUrl);
      } catch {
        addToast('Movie not found.', 'error');
        navigate('/');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  const validate = () => {
    const e = {};
    if (!form.title.trim()) e.title = 'Title is required';
    if (!form.description.trim()) e.description = 'Description is required';
    if (!form.genre) e.genre = 'Genre is required';
    if (!form.releaseYear || form.releaseYear < 1900 || form.releaseYear > 2030)
      e.releaseYear = 'Enter a valid year';
    if (!form.rating || form.rating < 0 || form.rating > 10)
      e.rating = 'Rating must be 0–10';
    if (!form.imageUrl.trim()) e.imageUrl = 'Image URL is required';
    return e;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: '' }));
    if (name === 'imageUrl') setPreview(value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setSaving(true);
    try {
      await updateMovie(id, {
        ...form,
        releaseYear: Number(form.releaseYear),
        rating: Number(form.rating),
      });
      addToast(`"${form.title}" updated successfully!`, 'success');
      navigate('/');
    } catch (err) {
      addToast(err.message || 'Update failed.', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loader fullScreen />;

  return (
    <div className="form-page">
      <div className="form-container">
        <div className="form-header">
          <button className="btn-back" onClick={() => navigate(-1)}>← Back</button>
          <h1 className="form-title">Edit Movie</h1>
          <p className="form-subtitle">Update the details for this title</p>
        </div>

        <div className="form-layout">
          <form className="movie-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label className="form-label">Movie Title *</label>
              <input className={`form-input${errors.title ? ' input-error' : ''}`} type="text" name="title" value={form.title} onChange={handleChange} />
              {errors.title && <span className="form-error">{errors.title}</span>}
            </div>

            <div className="form-group">
              <label className="form-label">Description *</label>
              <textarea className={`form-input form-textarea${errors.description ? ' input-error' : ''}`} name="description" value={form.description} onChange={handleChange} rows={4} />
              {errors.description && <span className="form-error">{errors.description}</span>}
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Genre *</label>
                <select className={`form-input form-select${errors.genre ? ' input-error' : ''}`} name="genre" value={form.genre} onChange={handleChange}>
                  <option value="">Select genre...</option>
                  {GENRES.map((g) => <option key={g} value={g}>{g}</option>)}
                </select>
                {errors.genre && <span className="form-error">{errors.genre}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">Release Year *</label>
                <input className={`form-input${errors.releaseYear ? ' input-error' : ''}`} type="number" name="releaseYear" value={form.releaseYear} onChange={handleChange} min="1900" max="2030" />
                {errors.releaseYear && <span className="form-error">{errors.releaseYear}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">Rating (0–10) *</label>
                <input className={`form-input${errors.rating ? ' input-error' : ''}`} type="number" name="rating" value={form.rating} onChange={handleChange} min="0" max="10" step="0.1" />
                {errors.rating && <span className="form-error">{errors.rating}</span>}
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Poster Image URL *</label>
              <input className={`form-input${errors.imageUrl ? ' input-error' : ''}`} type="url" name="imageUrl" value={form.imageUrl} onChange={handleChange} />
              {errors.imageUrl && <span className="form-error">{errors.imageUrl}</span>}
            </div>

            <div className="form-actions">
              <button type="button" className="btn-secondary" onClick={() => navigate('/')}>Cancel</button>
              <button type="submit" className="btn-primary" disabled={saving}>
                {saving ? 'Saving...' : '✓ Save Changes'}
              </button>
            </div>
          </form>

          <div className="form-preview">
            <h3 className="preview-label">Poster Preview</h3>
            <div className="preview-card">
              {preview ? (
                <img src={preview} alt="Preview" className="preview-img" onError={(e) => { e.target.style.display = 'none'; }} />
              ) : (
                <div className="preview-placeholder">
                  <p>No image</p>
                </div>
              )}
            </div>
            {form.title && (
              <div className="preview-info">
                <h4>{form.title}</h4>
                <p>{form.genre} {form.releaseYear && `• ${form.releaseYear}`} {form.rating && `• ★ ${form.rating}`}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditMovie;
