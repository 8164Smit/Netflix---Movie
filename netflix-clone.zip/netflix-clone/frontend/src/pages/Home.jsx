import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import MovieRow from '../components/MovieRow';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import { SkeletonRow } from '../components/SkeletonCard';
import { fetchMovies, deleteMovie, seedMovies } from '../services/api';
import { useToast } from '../context/ToastContext';

const HERO_MOVIES = [
  {
    title: "Epic Cinema Awaits",
    description: "Discover, manage, and explore your ultimate movie collection. Stream the world's best stories.",
    bg: "",
  },
];

const Home = ({ searchQuery, genreFilter }) => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const { addToast } = useToast();
  const navigate = useNavigate();

  const loadMovies = async () => {
    try {
      setLoading(true);
      const res = await fetchMovies(searchQuery, genreFilter);
      setMovies(res.data || []);
    } catch (err) {
      addToast('Failed to load movies. Is the backend running?', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMovies();
  }, [searchQuery, genreFilter]);

  const handleDeleteRequest = (id, title) => {
    setDeleteTarget({ id, title });
    setSelectedMovie(null);
  };

  const confirmDelete = async () => {
    try {
      await deleteMovie(deleteTarget.id);
      addToast(`"${deleteTarget.title}" deleted successfully.`, 'success');
      setDeleteTarget(null);
      loadMovies();
    } catch {
      addToast('Failed to delete movie.', 'error');
      setDeleteTarget(null);
    }
  };

  const handleSeed = async () => {
    try {
      await seedMovies();
      addToast('Sample movies loaded!', 'success');
      loadMovies();
    } catch {
      addToast('Failed to seed data.', 'error');
    }
  };

  // Group movies by genre
  const trending = movies.slice(0, 8);
  const topRated = [...movies].sort((a, b) => b.rating - a.rating).slice(0, 8);
  const byGenre = (g) => movies.filter((m) => m.genre === g);

  const heroMovie = HERO_MOVIES[0];
  const featuredMovie = movies[0];

  return (
    <div className="home-page">
      {/* Hero */}
      <div className="hero" style={{ backgroundImage: `url(${featuredMovie?.imageUrl || heroMovie.bg})` }}>
        <div className="hero-gradient" />
        <div className="hero-content">
          <div className="hero-badge">🎬 Now Streaming</div>
          <h1 className="hero-title">
            {featuredMovie ? featuredMovie.title : heroMovie.title}
          </h1>
          <p className="hero-desc">
            {featuredMovie ? featuredMovie.description : heroMovie.description}
          </p>
          <div className="hero-buttons">
            <button className="btn-hero-play" onClick={() => featuredMovie && setSelectedMovie(featuredMovie)}>
              ▶ Play
            </button>
            <button className="btn-hero-info" onClick={() => featuredMovie && setSelectedMovie(featuredMovie)}>
              ℹ More Info
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="home-content">
        {movies.length === 0 && !loading && (
          <div className="empty-state">
            <div className="empty-icon">🎬</div>
            <h2>No movies found</h2>
            <p>Your collection is empty. Add movies or load sample data.</p>
            <div className="empty-actions">
              <button className="btn-primary" onClick={() => navigate('/add')}>+ Add Movie</button>
              <button className="btn-secondary" onClick={handleSeed}>Load Sample Data</button>
            </div>
          </div>
        )}

        {loading ? (
          <>
            <SkeletonRow />
            <SkeletonRow />
            <SkeletonRow />
          </>
        ) : (
          <>
            {trending.length > 0 && (
              <MovieRow
                title="🔥 Trending Now"
                movies={trending}
                onDelete={handleDeleteRequest}
                onCardClick={setSelectedMovie}
              />
            )}
            {topRated.length > 0 && (
              <MovieRow
                title="⭐ Top Rated"
                movies={topRated}
                onDelete={handleDeleteRequest}
                onCardClick={setSelectedMovie}
              />
            )}
            {['Action', 'Sci-Fi', 'Drama', 'Comedy', 'Horror', 'Thriller', 'Animation'].map((g) => {
              const gMovies = byGenre(g);
              return gMovies.length > 0 ? (
                <MovieRow
                  key={g}
                  title={`🎭 ${g}`}
                  movies={gMovies}
                  onDelete={handleDeleteRequest}
                  onCardClick={setSelectedMovie}
                />
              ) : null;
            })}
          </>
        )}
      </div>

      {selectedMovie && (
        <Modal
          movie={selectedMovie}
          onClose={() => setSelectedMovie(null)}
          onDelete={handleDeleteRequest}
        />
      )}

      {deleteTarget && (
        <ConfirmDialog
          title={deleteTarget.title}
          onConfirm={confirmDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  );
};

export default Home;
