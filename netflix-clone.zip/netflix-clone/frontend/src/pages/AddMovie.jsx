import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createMovie } from '../services/api';
import { useToast } from '../context/ToastContext';

const GENRES = ['Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi', 'Romance', 'Thriller', 'Animation', 'Documentary', 'Fantasy'];

const INITIAL = {
  title: '',
  description: '',
  genre: '',
  releaseYear: '',
  rating: '',
  imageUrl: '',
};

const AddMovie = () => {
  const [form, setForm] = useState(INITIAL);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState('');
  const navigate = useNavigate();
  const { addToast } = useToast();

  const validate = () => {
    const e = {};
    if (!form.title.trim()) e.title = 'Title is required';
    if (!form.description.trim()) e.description = 'Description is required';
    if (!form.genre) e.genre = 'Genre is required';
    if (!form.releaseYear || form.releaseYear < 1900 || form.releaseYear > 2030)
      e.releaseYear = 'Enter a valid year (1900–2030)';
    if (!form.rating || form.rating < 0 || form.rating > 10)
      e.rating = 'Rating must be 0–10';
    if (!form.imageUrl.trim()) e.imageUrl = 'Image URL is required';
    return e;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: '' }));
    if (name === 'imageUrl') setPreview(value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    try {
      await createMovie({
        ...form,
        releaseYear: Number(form.releaseYear),
        rating: Number(form.rating),
      });
      addToast(`"${form.title}" added successfully!`, 'success');
      navigate('/');
    } catch (err) {
      addToast(err.message || 'Failed to add movie.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="form-page">
      <div className="form-container">
        <div className="form-header">
          <button className="btn-back" onClick={() => navigate(-1)}>← Back</button>
          <h1 className="form-title">Add New Movie</h1>
          <p className="form-subtitle">Add a new title to your collection</p>
        </div>

        <div className="form-layout">
          <form className="movie-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label className="form-label">Movie Title *</label>
              <input
                className={`form-input${errors.title ? ' input-error' : ''}`}
                type="text"
                name="title"
                value={form.title}
                onChange={handleChange}
                placeholder="e.g. The Dark Knight"
              />
              {errors.title && <span className="form-error">{errors.title}</span>}
            </div>

            <div className="form-group">
              <label className="form-label">Description *</label>
              <textarea
                className={`form-input form-textarea${errors.description ? ' input-error' : ''}`}
                name="description"
                value={form.description}
                onChange={handleChange}
                placeholder="Brief plot summary..."
                rows={4}
              />
              {errors.description && <span className="form-error">{errors.description}</span>}
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Genre *</label>
                <select
                  className={`form-input form-select${errors.genre ? ' input-error' : ''}`}
                  name="genre"
                  value={form.genre}
                  onChange={handleChange}
                >
                  <option value="">Select genre...</option>
                  {GENRES.map((g) => <option key={g} value={g}>{g}</option>)}
                </select>
                {errors.genre && <span className="form-error">{errors.genre}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">Release Year *</label>
                <input
                  className={`form-input${errors.releaseYear ? ' input-error' : ''}`}
                  type="number"
                  name="releaseYear"
                  value={form.releaseYear}
                  onChange={handleChange}
                  placeholder="2024"
                  min="1900"
                  max="2030"
                />
                {errors.releaseYear && <span className="form-error">{errors.releaseYear}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">Rating (0–10) *</label>
                <input
                  className={`form-input${errors.rating ? ' input-error' : ''}`}
                  type="number"
                  name="rating"
                  value={form.rating}
                  onChange={handleChange}
                  placeholder="8.5"
                  min="0"
                  max="10"
                  step="0.1"
                />
                {errors.rating && <span className="form-error">{errors.rating}</span>}
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Poster Image URL *</label>
              <input
                className={`form-input${errors.imageUrl ? ' input-error' : ''}`}
                type="url"
                name="imageUrl"
                value={form.imageUrl}
                onChange={handleChange}
                placeholder="https://image.tmdb.org/t/p/w500/..."
              />
              {errors.imageUrl && <span className="form-error">{errors.imageUrl}</span>}
            </div>

            <div className="form-actions">
              <button type="button" className="btn-secondary" onClick={() => navigate('/')}>
                Cancel
              </button>
              <button type="submit" className="btn-primary" disabled={loading}>
                {loading ? 'Adding...' : '+ Add Movie'}
              </button>
            </div>
          </form>

          <div className="form-preview">
            <h3 className="preview-label">Poster Preview</h3>
            <div className="preview-card">
              {preview ? (
                <img
                  src={preview}
                  alt="Preview"
                  className="preview-img"
                  onError={(e) => { e.target.style.display = 'none'; }}
                />
              ) : (
                <div className="preview-placeholder">
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#444" strokeWidth="1">
                    <rect x="2" y="2" width="20" height="20" rx="2" />
                    <circle cx="8.5" cy="8.5" r="1.5" />
                    <polyline points="21 15 16 10 5 21" />
                  </svg>
                  <p>Poster appears here</p>
                </div>
              )}
            </div>
            {form.title && (
              <div className="preview-info">
                <h4>{form.title}</h4>
                <p>{form.genre} {form.releaseYear && `• ${form.releaseYear}`} {form.rating && `• ★ ${form.rating}`}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddMovie;
