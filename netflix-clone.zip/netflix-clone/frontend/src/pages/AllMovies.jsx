import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchMovies, deleteMovie } from '../services/api';
import { useToast } from '../context/ToastContext';
import MovieCard from '../components/MovieCard';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import Loader from '../components/Loader';

const GENRES = ['All', 'Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi', 'Romance', 'Thriller', 'Animation', 'Documentary', 'Fantasy'];

const AllMovies = ({ searchQuery }) => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [genreFilter, setGenreFilter] = useState('All');
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const { addToast } = useToast();
  const navigate = useNavigate();

  const loadMovies = async () => {
    try {
      setLoading(true);
      const res = await fetchMovies(searchQuery, genreFilter);
      setMovies(res.data || []);
    } catch {
      addToast('Failed to load movies.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadMovies(); }, [searchQuery, genreFilter]);

  const handleDeleteRequest = (id, title) => {
    setDeleteTarget({ id, title });
    setSelectedMovie(null);
  };

  const confirmDelete = async () => {
    try {
      await deleteMovie(deleteTarget.id);
      addToast(`"${deleteTarget.title}" deleted.`, 'success');
      setDeleteTarget(null);
      loadMovies();
    } catch {
      addToast('Delete failed.', 'error');
      setDeleteTarget(null);
    }
  };

  return (
    <div className="all-movies-page">
      <div className="all-movies-header">
        <h1>All Movies</h1>
        <button className="btn-primary" onClick={() => navigate('/add')}>+ Add Movie</button>
      </div>

      <div className="genre-filter-bar">
        {GENRES.map((g) => (
          <button
            key={g}
            className={`genre-pill${genreFilter === g ? ' genre-pill--active' : ''}`}
            onClick={() => setGenreFilter(g)}
          >
            {g}
          </button>
        ))}
      </div>

      {loading ? (
        <Loader />
      ) : movies.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🎬</div>
          <h2>No movies found</h2>
          <p>Try a different search or genre filter.</p>
          <button className="btn-primary" onClick={() => navigate('/add')}>+ Add Movie</button>
        </div>
      ) : (
        <>
          <p className="movies-count">{movies.length} title{movies.length !== 1 ? 's' : ''}</p>
          <div className="movies-grid">
            {movies.map((movie) => (
              <MovieCard
                key={movie._id}
                movie={movie}
                onDelete={handleDeleteRequest}
                onClick={setSelectedMovie}
              />
            ))}
          </div>
        </>
      )}

      {selectedMovie && (
        <Modal movie={selectedMovie} onClose={() => setSelectedMovie(null)} onDelete={handleDeleteRequest} />
      )}
      {deleteTarget && (
        <ConfirmDialog title={deleteTarget.title} onConfirm={confirmDelete} onCancel={() => setDeleteTarget(null)} />
      )}
    </div>
  );
};

export default AllMovies;
