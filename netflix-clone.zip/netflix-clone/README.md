# 🎬 CineVault — Netflix-Style Movie Management System

A full-stack CRUD movie management app with a premium Netflix-inspired dark UI.

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React.js + Vite |
| Styling | 100% Custom CSS (no frameworks) |
| Backend | Node.js + Express.js |
| Database | MongoDB + Mongoose |
| Routing | React Router v6 |
| State | useState + useEffect |

## Features

- 🎬 **Netflix-inspired UI** — dark theme, horizontal scroll rows, hover animations
- ✅ **Full CRUD** — Add, View, Edit, Delete movies
- 🔍 **Search** — real-time search by title
- 🎭 **Genre Filter** — filter by Action, Drama, Sci-Fi, etc.
- 🔔 **Toast Notifications** — custom success/error notifications
- 💀 **Skeleton Loading** — placeholder cards while data loads
- 📱 **Fully Responsive** — mobile + desktop
- 🎞 **Movie Detail Modal** — click any card to view full details
- 🗑 **Delete Confirmation** — confirm before deleting
- 🌱 **Sample Data Seeder** — one-click load 12 sample movies

## Project Structure

```
netflix-clone/
├── backend/
│   ├── config/db.js          ← MongoDB connection
│   ├── models/Movie.js       ← Mongoose schema
│   ├── controllers/          ← Business logic
│   ├── routes/movieRoutes.js ← RESTful routes
│   └── server.js             ← Express entry
│
├── frontend/
│   └── src/
│       ├── components/
│       │   ├── Navbar.jsx
│       │   ├── MovieCard.jsx
│       │   ├── MovieRow.jsx
│       │   ├── Modal.jsx
│       │   ├── ConfirmDialog.jsx
│       │   ├── Loader.jsx
│       │   └── SkeletonCard.jsx
│       ├── context/
│       │   └── ToastContext.jsx
│       ├── pages/
│       │   ├── Home.jsx
│       │   ├── AddMovie.jsx
│       │   ├── EditMovie.jsx
│       │   └── AllMovies.jsx
│       ├── services/api.js
│       ├── App.jsx
│       ├── main.jsx
│       └── styles.css        ← ALL custom CSS here
│
└── README.md
```

## Setup & Run

### Prerequisites
- Node.js v18+
- MongoDB running locally (`mongodb://localhost:27017`)

### 1. Backend

```bash
cd backend
npm install
npm run dev
```

Server runs at: `http://localhost:5000`

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

App runs at: `http://localhost:3000`

### 3. Load Sample Data

Open the app → click **"Load Sample Data"** on the empty homepage,  
OR send a POST request to:
```
POST http://localhost:5000/api/movies/seed/data
```

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/movies` | Fetch all movies (supports `?search=` and `?genre=`) |
| GET | `/api/movies/:id` | Fetch single movie |
| POST | `/api/movies` | Create new movie |
| PUT | `/api/movies/:id` | Update movie |
| DELETE | `/api/movies/:id` | Delete movie |
| POST | `/api/movies/seed/data` | Load 12 sample movies |

## MongoDB Schema

```js
{
  title: String,          // required
  description: String,    // required
  genre: String,          // enum: Action/Comedy/Drama/...
  releaseYear: Number,    // 1900–2030
  rating: Number,         // 0–10
  imageUrl: String        // poster URL
}
```

## Environment Variables

Create `backend/.env`:
```
MONGO_URI=mongodb://localhost:27017/netflix_movies
PORT=5000
```

---

Built with ❤️ for BCA Final Year Project
