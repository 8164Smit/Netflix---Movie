const Movie = require('../models/Movie');

// GET all movies
const getAllMovies = async (req, res) => {
  try {
    const { search, genre } = req.query;
    let filter = {};

    if (search) {
      filter.title = { $regex: search, $options: 'i' };
    }
    if (genre && genre !== 'All') {
      filter.genre = genre;
    }

    const movies = await Movie.find(filter).sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: movies.length, data: movies });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET single movie
const getMovieById = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) return res.status(404).json({ success: false, message: 'Movie not found' });
    res.status(200).json({ success: true, data: movie });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST create movie
const createMovie = async (req, res) => {
  try {
    const movie = await Movie.create(req.body);
    res.status(201).json({ success: true, data: movie });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// PUT update movie
const updateMovie = async (req, res) => {
  try {
    const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!movie) return res.status(404).json({ success: false, message: 'Movie not found' });
    res.status(200).json({ success: true, data: movie });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// DELETE movie
const deleteMovie = async (req, res) => {
  try {
    const movie = await Movie.findByIdAndDelete(req.params.id);
    if (!movie) return res.status(404).json({ success: false, message: 'Movie not found' });
    res.status(200).json({ success: true, message: 'Movie deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST seed sample data
const seedMovies = async (req, res) => {
  try {
    await Movie.deleteMany({});
    const sampleMovies = [
      {
        title: "Inception",
        description: "A thief who steals corporate secrets through dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
        genre: "Sci-Fi",
        releaseYear: 2010,
        rating: 8.8,
        imageUrl: "https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg"
      },
      {
        title: "The Dark Knight",
        description: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.",
        genre: "Action",
        releaseYear: 2008,
        rating: 9.0,
        imageUrl: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg"
      },
      {
        title: "Interstellar",
        description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
        genre: "Sci-Fi",
        releaseYear: 2014,
        rating: 8.6,
        imageUrl: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg"
      },
      {
        title: "Parasite",
        description: "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan.",
        genre: "Thriller",
        releaseYear: 2019,
        rating: 8.5,
        imageUrl: "https://image.tmdb.org/t/p/w500/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg"
      },
      {
        title: "The Shawshank Redemption",
        description: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
        genre: "Drama",
        releaseYear: 1994,
        rating: 9.3,
        imageUrl: "https://image.tmdb.org/t/p/w500/lyQBXzOQSuE59IsHyhrp0qIiPAz.jpg"
      },
      {
        title: "Spirited Away",
        description: "During her family's move to the suburbs, a sullen 10-year-old girl wanders into a world ruled by gods, witches, and spirits.",
        genre: "Animation",
        releaseYear: 2001,
        rating: 8.6,
        imageUrl: "https://image.tmdb.org/t/p/w500/39wmItIWsg5sZMyRUHLkWBcuVCM.jpg"
      },
      {
        title: "Avengers: Endgame",
        description: "After the devastating events of Infinity War, the universe is in ruins. The Avengers assemble once more to reverse Thanos' actions.",
        genre: "Action",
        releaseYear: 2019,
        rating: 8.4,
        imageUrl: "https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg"
      },
      {
        title: "Get Out",
        description: "A young African-American visits his white girlfriend's parents for the weekend, where his simmering uneasiness about their reception of him eventually reaches a terrifying peak.",
        genre: "Horror",
        releaseYear: 2017,
        rating: 7.7,
        imageUrl: "https://image.tmdb.org/t/p/w500/tFXcEccSQMf3lfhfXKSU9iRBpa3.jpg"
      },
      {
        title: "The Grand Budapest Hotel",
        description: "A writer encounters the owner of an aging European hotel between the two World Wars and gets embroiled in a fast-paced adventure.",
        genre: "Comedy",
        releaseYear: 2014,
        rating: 8.1,
        imageUrl: "https://image.tmdb.org/t/p/w500/eWDzbqd7FXkXEOrBnMFBmRNT7TM.jpg"
      },
      {
        title: "Dune",
        description: "Feature adaptation of Frank Herbert's science fiction novel about the son of a noble family entrusted with the protection of the most valuable asset in the galaxy.",
        genre: "Sci-Fi",
        releaseYear: 2021,
        rating: 8.0,
        imageUrl: "https://image.tmdb.org/t/p/w500/d5NXSklpcvweasiyGdIGBDLnAKi.jpg"
      },
      {
        title: "Coco",
        description: "Aspiring musician Miguel, confronted with his family's ban on music, enters the Land of the Dead to find his great-great-grandfather.",
        genre: "Animation",
        releaseYear: 2017,
        rating: 8.4,
        imageUrl: "https://image.tmdb.org/t/p/w500/gGEsBPAijhVUFoiNpgZXqRVWJt2.jpg"
      },
      {
        title: "Knives Out",
        description: "A detective investigates the death of a patriarch of an eccentric, combative family.",
        genre: "Thriller",
        releaseYear: 2019,
        rating: 7.9,
        imageUrl: "https://image.tmdb.org/t/p/w500/pThyQovXQrws2hmUT087tS75Gzw.jpg"
      }
    ];
    const movies = await Movie.insertMany(sampleMovies);
    res.status(201).json({ success: true, count: movies.length, message: 'Sample data seeded successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getAllMovies, getMovieById, createMovie, updateMovie, deleteMovie, seedMovies };
