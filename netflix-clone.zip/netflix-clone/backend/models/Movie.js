const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      trim: true,
    },
    genre: {
      type: String,
      required: [true, 'Genre is required'],
      enum: ['Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi', 'Romance', 'Thriller', 'Animation', 'Documentary', 'Fantasy'],
    },
    releaseYear: {
      type: Number,
      required: [true, 'Release year is required'],
      min: 1900,
      max: new Date().getFullYear() + 2,
    },
    rating: {
      type: Number,
      required: [true, 'Rating is required'],
      min: 0,
      max: 10,
    },
    imageUrl: {
      type: String,
      required: [true, 'Image URL is required'],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Movie', movieSchema);
